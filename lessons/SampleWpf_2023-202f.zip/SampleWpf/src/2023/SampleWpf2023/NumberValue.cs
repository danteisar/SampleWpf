﻿namespace SampleWpf2023;

public enum NumberValue
{
    LessZero,
    Zero,   
    UpperZero
}   