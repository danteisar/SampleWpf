﻿using System;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace SampleWpf2023.Views;

/// <summary>
/// Логика взаимодействия для CounterView.xaml
/// </summary>
public partial class CounterView
{
    public CounterView()
    {
        InitializeComponent();
    }
}