﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfApp1.Components;

/// <summary>
/// Логика взаимодействия для Digit.xaml
/// </summary>
public partial class Digit : UserControl
{
    public Digit()
    {
        InitializeComponent();  
    }

    public Brush MarkBackground
    {
        get { return (Brush)GetValue(MarkBackgroundProperty); }
        set { SetValue(MarkBackgroundProperty, value); }
    }

    public static readonly DependencyProperty MarkBackgroundProperty =
        DependencyProperty.Register(nameof(MarkBackground), typeof(Brush), typeof(Digit), new PropertyMetadata(new SolidColorBrush(Colors.Red)));
}
